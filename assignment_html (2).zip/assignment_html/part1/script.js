document.addEventListener('DOMContentLoaded', () => {
  // 1. Contact Form validation
  const contactForm = document.getElementById('contactForm');
  contactForm.addEventListener('submit', (event) => {
    if (!contactForm.checkValidity()) {
      event.preventDefault();
      event.stopPropagation();
    }
    contactForm.classList.add('was-validated');
  });

  // 2. Registration Form logic & password matching
  const regForm = document.getElementById('registrationForm');
  const password = document.getElementById('regPassword');
  const confirmPassword = document.getElementById('regConfirmPassword');
  const successAlert = document.getElementById('registrationSuccessAlert');
  const resetBtn = document.getElementById('resetBtn');

  function checkPasswordMatch() {
    if (confirmPassword.value && password.value !== confirmPassword.value) {
      confirmPassword.setCustomValidity('Пароли не совпадают');
      confirmPassword.classList.add('is-invalid');
    } else {
      confirmPassword.setCustomValidity('');
      confirmPassword.classList.remove('is-invalid');
    }
  }

  password.addEventListener('input', checkPasswordMatch);
  confirmPassword.addEventListener('input', checkPasswordMatch);

  regForm.addEventListener('submit', (event) => {
    checkPasswordMatch();

    if (!regForm.checkValidity()) {
      event.preventDefault();
      event.stopPropagation();
      successAlert.classList.add('d-none');
    } else {
      event.preventDefault(); // Предотвращаем перезагрузку страницы для демо
      successAlert.classList.remove('d-none');
      regForm.reset();
      regForm.classList.remove('was-validated');
    }

    regForm.classList.add('was-validated');
  });

  // Reset button logic: очищает поля и стили валидации
  resetBtn.addEventListener('click', () => {
    regForm.classList.remove('was-validated');
    confirmPassword.classList.remove('is-invalid');
    confirmPassword.setCustomValidity('');
    successAlert.classList.add('d-none');
  });
});